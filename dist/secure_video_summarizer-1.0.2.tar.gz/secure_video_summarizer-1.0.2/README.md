# Secure Video Summarizer

A Chrome extension and backend service to securely summarize video content using local AI processing.

## Features

- Chrome extension for detecting and processing videos from various platforms
- Secure summarization of video content using local AI
- Support for YouTube and Olympus LMS video platforms
- Transcript generation and summarization
- Self-hosted backend for enhanced privacy

## Installation Options

### Option 1: Easy Install Script

```bash
# Clone the repository
git clone https://github.com/yourusername/secure-video-summarizer.git
cd secure-video-summarizer

# Run the installation script
chmod +x install.sh
./install.sh
```

### Option 2: Docker Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/secure-video-summarizer.git
cd secure-video-summarizer

# Build and start the Docker containers
docker-compose up -d
```

### Option 3: Manual Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/secure-video-summarizer.git
cd secure-video-summarizer

# Create a virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Setup the Chrome extension
cd extension
npm install
npm run build
cd ..

# Start the backend service
cd backend
flask run --port=8081 --debug
```

## Usage

1. Start the backend service:
   ```bash
   cd backend
   flask run --port=8081 --debug
   ```

2. Load the Chrome extension:
   - Open Chrome and navigate to `chrome://extensions/`
   - Enable "Developer mode"
   - Click "Load unpacked" and select the `extension/dist` folder

3. Use the extension:
   - Navigate to a video on a supported platform
   - Click the extension icon
   - Follow the prompts to generate a summary

## Configuration

The application can be configured using environment variables in a `.env` file:

```
SECRET_KEY=your_secret_key
FLASK_ENV=production
OLLAMA_API_URL=http://localhost:11434/api
```

## Supported Platforms

- YouTube
- Olympus LMS

## License

MIT License
